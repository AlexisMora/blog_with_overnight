import { LoginServer } from "./LoginServer";

const server = new LoginServer()
server.start(3000)  