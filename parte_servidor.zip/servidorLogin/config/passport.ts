import * as passport from "passport"
import * as passportLocal from "passport-local"
const GoogleStrategy = require('passport-google-oauth20').Strategy
const LocalStrategy = passportLocal.Strategy;

passport.serializeUser((user,done) => {
    done(null,user)
});

passport.deserializeUser((user,done) => {
    done(null,user)
});

passport.use(new LocalStrategy({
        usernameField: 'usuari',
        passwordField: 'contrasenya'
    },
    function(username:any, password:any, done:any) {
        console.log('Entra',username, password);
        /*
        1º cas
        done(err) --> hi ha hagut un error (err)
        2º cas
        done(null,false) --> no hi ha hagut error però no és vàlid l'usuari
        3º cas
        done(null,true o user...) --> usuari autenticat correctament
         */
        console.log('ENTRA A PASSPORT LOCAL');

        return done(null,{
            nom: 'Joan'
        });

        /*User.findOne({ username: username }, function (err, user) {
            if (err) { return done(err); }
            if (!user) { return done(null, false); }
            if (!user.verifyPassword(password)) { return done(null, false); }
            return done(null, user);
        });*/
    }
));

passport.use(new GoogleStrategy({
    clientID:"456348531371-6b75so7kns8a7c9snrgdqm7db9ulipfj.apps.googleusercontent.com",
    clientSecret: "n9whSfs8QUyOlBLb-bINS_kB",
    callbackURL:"http://localhost:3000/auth/google/callback",
    passReqToCallback: true,
},
function(request:any, accessToken:any, refreshToken:any, profile:any, done:any) {
    console.log(profile.emails[0].value)
    return done(null,profile.emails[0].value)
  }
))