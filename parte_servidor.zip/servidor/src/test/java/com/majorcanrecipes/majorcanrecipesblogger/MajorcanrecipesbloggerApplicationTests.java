package com.majorcanrecipes.majorcanrecipesblogger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MajorcanrecipesbloggerApplicationTests {

    @Test
    void contextLoads() {
    }

}
